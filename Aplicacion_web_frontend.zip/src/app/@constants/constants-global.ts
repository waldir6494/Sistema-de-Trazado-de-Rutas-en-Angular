export const ESTADO_MODAL_CORRECTO = 1;
export const ESTADO_MODAL_ERROR = 2;
export const ESTADO_MODAL_EXISTE = 3;
export const GOOGLE_KEY ='AIzaSyDBHjKtZO05Kkf7ooCRcRf-P8Z-yDQ57io';