export const HOSTSERVER = 'https://proyecto-back-unsa.herokuapp.com/api';
