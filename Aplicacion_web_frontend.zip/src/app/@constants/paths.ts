import * as server from './HOSTSERVER';

export const HOSTSERVICE_MSFINANZAS = server.HOSTSERVER + '/MSFinanzas';
export const HOSTSERVICE_MSSEGURIDAD = server.HOSTSERVER + '/MSSeguridad';


export class Rutas {
    RUTA_SERVER_LOGISTICA_V1 = server.HOSTSERVER + '/MSLogistica/api/v1/';
}
//poner rutas