export interface Marker {
	//id?: number
	id?:number;
	latitude: number;
	longitude: number;
	label: string;
}
