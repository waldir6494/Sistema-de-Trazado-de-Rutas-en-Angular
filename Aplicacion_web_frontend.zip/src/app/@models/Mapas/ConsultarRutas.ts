export interface ConsultarRutas {
	//id?: number
	idJuego:number;
	tamanio: number;
}