export interface actualizarRuta {
	idsJugadores: number[];
	idRuta:number;
}