export interface Puntos {
	idPuntos?:number;
	idJuego?: number;
	NombrePunto: string;
	Alias: number;
	Latitud: number;
	Longitud: number;
}