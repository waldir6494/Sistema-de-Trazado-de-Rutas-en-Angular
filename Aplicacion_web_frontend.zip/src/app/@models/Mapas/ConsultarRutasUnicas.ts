export interface ConsultarRutasUnicas {
	//id?: number
	idJuego:number;
	tamanio: number;
	idPunto: number;
}