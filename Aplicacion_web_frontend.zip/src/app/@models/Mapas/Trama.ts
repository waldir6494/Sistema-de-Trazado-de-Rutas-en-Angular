export interface Trama {
	idTrama?:number;
	idPuntoOrigen: number;
	idPuntoDestino: number;
	Distancia: number;
}