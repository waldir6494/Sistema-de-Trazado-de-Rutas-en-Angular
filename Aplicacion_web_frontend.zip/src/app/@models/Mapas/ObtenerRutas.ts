export interface ObtenerRutas {
	//id?: number
	data:number;
	_child:string;
	dist_total:number;
	visited_nodes: string[];
}