export interface Generico{
    Total?: number;
}