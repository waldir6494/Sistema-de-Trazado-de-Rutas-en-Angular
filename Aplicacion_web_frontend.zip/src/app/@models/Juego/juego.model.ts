export class Juego{
    idJuego?: number;
    idAdministrador?: string;
    NombreJuego?: string;
    Inicio?: string;
    Fin?: string;
    Intentos?: string;
    Tiempo?: string;
    Cerrado?: string;
}