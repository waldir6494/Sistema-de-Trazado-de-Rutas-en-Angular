export class Pregunta{
    Imagen?: string;
    imagen?: any;
    NombreImagen?: string;
    Pregunta?: string;
    Respuesta?: string;
    idJuego?: string;
    idPreguntas?: number;
}