export interface Tablaid {
	//id?: number
	idJugadores: number[];
}
