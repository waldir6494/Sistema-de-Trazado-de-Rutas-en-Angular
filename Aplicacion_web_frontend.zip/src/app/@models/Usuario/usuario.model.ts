export class Usuario{
    id?: number;
    Nombre: string;
    Usuario: string;
    Correo: string;
}