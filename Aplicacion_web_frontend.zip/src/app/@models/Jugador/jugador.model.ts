export class Jugador{
    idJugador?: number;
    idJuego?: number;
    Celular?: string;
    Correo?: string;
    Nombrejugador?: string;
    Notificado?: string;
}