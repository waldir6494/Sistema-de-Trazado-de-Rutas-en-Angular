export class UsuarioRegistro {
	Nombre:string;
	Usuario;
	Correo: string;
	password: string;
    confirmPassword: string;
}