import { SpinnerService } from 'src/app/shared/spinner/spinner.service';
import { AlertService } from 'src/app/shared/alert/alert.service';

export const injectableJuegos: any[] = [
  SpinnerService,
  AlertService
]
