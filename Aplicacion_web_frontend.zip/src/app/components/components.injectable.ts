import { ToolbarService } from 'src/app/@services/Toolbar/toolbar.service';

export const injectableComponents: any[] = [
  ToolbarService
]
